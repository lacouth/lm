# CSS Selector Extension

Active query selector elements


## Installing 

* [Firefox](https://developer.mozilla.org/en-US/Add-ons/WebExtensions/Your_first_WebExtension#Installing)
* [Chrome]
(https://developer.chrome.com/extensions/getstarted#manifest)